import json
def handler(request):
    return json.dumps({"ok": True})
